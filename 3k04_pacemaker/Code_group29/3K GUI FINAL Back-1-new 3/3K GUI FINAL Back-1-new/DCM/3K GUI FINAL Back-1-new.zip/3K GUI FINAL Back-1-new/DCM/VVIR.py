import tkinter as pk
import tkinter.messagebox
from tkinter import *
from functions import *


def VVIR_window():
    root_VVIR = pk.Tk()
    root_VVIR.title('VVIR')
    root_VVIR.geometry('280x335')

    try:
        file = open("VVIR_parameter.txt", "r")
    except:
        file = open("VVIR_parameter.txt", "w+")

    Label(root_VVIR, text='Lower Rate Limit:').grid(row=0, column=0)
    Label(root_VVIR, text='Upper Rate Limit:').grid(row=1, column=0)
    Label(root_VVIR, text='Maximum Sensor Rate:').grid(row=2, column=0)
    Label(root_VVIR, text='Atrial Amplitude:').grid(row=3, column=0)
    Label(root_VVIR, text='Atrial Pulse Width:').grid(row=4, column=0)
    Label(root_VVIR, text='Atrial Sensitivity:').grid(row=5, column=0)
    Label(root_VVIR, text='ARP:').grid(row=6, column=0)
    Label(root_VVIR, text='PVARP:').grid(row=7, column=0)
    Label(root_VVIR, text='Hysteresis:').grid(row=8, column=0)
    Label(root_VVIR, text='Rate Smoothing:').grid(row=9, column=0)
    Label(root_VVIR, text='Activity Threshold:').grid(row=10, column=0)
    Label(root_VVIR, text='Reaction Time:').grid(row=11, column=0)
    Label(root_VVIR, text='Response Factor:').grid(row=12, column=0)
    Label(root_VVIR, text='Recovery Time:').grid(row=13, column=0)

    v1 = pk.StringVar()
    v1.set(file.readline().strip())
    v2 = pk.StringVar()
    v2.set(file.readline().strip())
    v3 = pk.StringVar()
    v3.set(file.readline().strip())
    v4 = pk.StringVar()
    v4.set(file.readline().strip())
    v5 = pk.StringVar()
    v5.set(file.readline().strip())
    v6 = pk.StringVar()
    v6.set(file.readline().strip())
    v7 = pk.StringVar()
    v7.set(file.readline().strip())
    v8 = pk.StringVar()
    v8.set(file.readline().strip())
    v9 = pk.StringVar()
    v9.set(file.readline().strip())
    v10 = pk.StringVar()
    v10.set(file.readline().strip())
    v11 = pk.StringVar()
    v11.set(file.readline().strip())
    v12 = pk.StringVar()
    v12.set(file.readline().strip())
    v13 = pk.StringVar()
    v13.set(file.readline().strip())

    e1 = Entry(root_VVIR, textvariable=v1)
    e2 = Entry(root_VVIR, textvariable=v2)
    e3 = Entry(root_VVIR, textvariable=v3)
    e4 = Entry(root_VVIR, textvariable=v4)
    e5 = Entry(root_VVIR, textvariable=v5)
    e6 = Entry(root_VVIR, textvariable=v6)
    e7 = Entry(root_VVIR, textvariable=v7)
    e8 = Entry(root_VVIR, textvariable=v8)
    e9 = Entry(root_VVIR, textvariable=v9)
    e10 = Entry(root_VVIR, textvariable=v10)
    e11 = Entry(root_VVIR, textvariable=v11)
    e12 = Entry(root_VVIR, textvariable=v12)
    e13 = Entry(root_VVIR, textvariable=v13)

    e1.grid(row=0, column=1, padx=10, pady=5)
    e2.grid(row=1, column=1, padx=10, pady=5)
    e3.grid(row=2, column=1, padx=10, pady=5)
    e4.grid(row=3, column=1, padx=10, pady=5)
    e5.grid(row=4, column=1, padx=10, pady=5)
    e6.grid(row=5, column=1, padx=10, pady=5)
    e7.grid(row=6, column=1, padx=10, pady=5)
    e8.grid(row=7, column=1, padx=10, pady=5)
    e9.grid(row=8, column=1, padx=10, pady=5)
    e10.grid(row=9, column=1, padx=10, pady=5)
    e11.grid(row=10, column=1, padx=10, pady=5)
    e12.grid(row=11, column=1, padx=10, pady=5)
    e13.grid(row=12, column=1, padx=10, pady=5)

    def show_VVIR():
        condition1 = 1
        condition2 = 1
        condition3 = 1
        condition4 = 1
        condition5 = 1

        print("Lower Rate Limit:%s" % e1.get())
        print("Upper Rate Limit:%s" % e2.get())
        print("Atrial Amplitude:%s" % e3.get())
        print("Atrial Pulse Width:%s" % e4.get())
        print("ARP:%s" % e5.get())

        file = open("AAI_parameter.txt", "w")
        # LRL input detecting
        if int(e1.get()) < 30:
            tkinter.messagebox.showerror('Error', 'Invalid Lower Rate Limit entered!\nPlease use another number!')
            condition1 = 0
        if 30 <= int(e1.get()) < 50:
            if int(e1.get()) % 5 != 0:
                tkinter.messagebox.showerror('Error', 'Invalid Lower Rate Limit entered!\nPlease use another number!')
                condition1 = 0
            else:
                file.write(e1.get() + "\n")
                condition1 = 1
        if 50 <= int(e1.get()) < 90:
            if int(e1.get()) % 1 != 0:
                tkinter.messagebox.showerror('Error', 'Invalid Lower Rate Limit entered!\nPlease use another number!')
                condition1 = 0
            else:
                file.write(e1.get() + "\n")
                condition1 = 1
        if 90 <= int(e1.get()) <= 175:
            if int(e1.get()) % 5 != 0:
                tkinter.messagebox.showerror('Error', 'Invalid Lower Rate Limit entered!\nPlease use another number!')
                condition1 = 0
            else:
                file.write(e1.get() + "\n")
                condition1 = 1
        if int(e1.get()) > 175:
            tkinter.messagebox.showerror('Error', 'Invalid Lower Rate Limit entered!\nPlease use another number!')
            condition1 = 0

        # URL input detecting
        if int(e2.get()) < 50:
            tkinter.messagebox.showerror('Error', 'Invalid Upper Rate Limit entered!\nPlease use another number!')
            condition2 = 0
        if int(e2.get()) > 175:
            tkinter.messagebox.showerror('Error', 'Invalid Upper Rate Limit entered!\nPlease use another number!')
            condition2 = 0
        if 50 <= int(e2.get()) <= 175:
            if int(e2.get()) % 5 != 0:
                tkinter.messagebox.showerror('Error', 'Invalid Upper Rate Limit entered!\nPlease use another number!')
                condition2 = 0
            else:
                file.write(e2.get() + "\n")
                condition2 = 1

        # AA input detecting
        if type(e3.get()) == type('abc'):
            if e3.get() == 'Off':
                file.write(e3.get() + "\n")
                condition3 = 1

            elif float(e3.get()) * 100 == 125 or float(e3.get()) * 100 == 250 or float(e3.get()) * 100 == 375 or int(
                    e3.get()) * 100 == 500:
                file.write(e3.get() + "\n")
                condition3 = 1

            else:
                tkinter.messagebox.showerror('Error', 'Invalid Atrial Amplitude entered!\nPlease use another number!')
                condition3 = 0

        # APW input detecting
        if 0.05 < float(e4.get()) < 0.1 or float(e4.get()) > 1.9 or float(e4.get()) < 0.05:
            tkinter.messagebox.showerror('Error', 'Invalid Atrial Pulse Width entered!\nPlease use another number!')
            condition4 = 0
        elif float(e4.get()) != 0.05:
            if float(e4.get()) % 0.1 != 0:
                tkinter.messagebox.showerror('Error', 'Invalid Atrial Pulse Width entered!\nPlease use another number!')
                condition4 = 0
            else:
                file.write(e4.get() + "\n")
                condition4 = 1
        else:
            file.write(e4.get() + "\n")
            condition4 = 1

        # ARP input detecting
        if int(e5.get()) < 150 or int(e5.get()) > 500:
            tkinter.messagebox.showerror('Error', 'Invalid ARP entered!\nPlease use another number!')
            condition5 = 0
        else:
            if int(e5.get()) % 10 != 0:
                tkinter.messagebox.showerror('Error', 'Invalid ARP entered!\nPlease use another number!')
                condition5 = 0
            else:
                file.write(e5.get() + "\n")
                condition5 = 1

        # Total Conditions
        if condition1 == 0 or condition2 == 0 or condition3 == 0 or condition4 == 0 or condition5 == 0:
            file.close()
            tkinter.messagebox.showerror('Error', 'Please try again!')
        if condition1 == 1 and condition2 == 1 and condition3 == 1 and condition4 == 1 and condition5 == 1:
            file.close()
            tkinter.messagebox.showinfo('Success', 'Successfully saved!')
            root_VVIR.destroy()

    Button(root_VVIR, text='Save', width=5, command=show_VVIR).place(x=50, y=290)
    Button(root_VVIR, text='Fire', width=5, command=root_VVIR.destroy).place(x=120, y=290)
    Button(root_VVIR, text='Cancel', width=5, command=root_VVIR.destroy).place(x=190, y=290)

    mainloop()
