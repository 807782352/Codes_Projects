import tkinter.messagebox

def success():
    tkinter.messagebox.showinfo('Success', 'Successfully saved!')

def Lower_Rate_Limit_Error():
    tkinter.messagebox.showerror('Error', 'Invalid Lower Rate Limit entered!\nPlease use another number!')
    tkinter.messagebox.showinfo("Tips",
                                "The value should be in one of the list below:\n - 30~50 with increment by 5\n -50~90 with increment by 1\n -  90~175 with increment by 5")


def Upper_Rate_Limit_Error():
    tkinter.messagebox.showerror('Error', 'Invalid Upper Rate Limit entered!\nPlease use another number!')
    tkinter.messagebox.showinfo("Tips",
                                "The value should be in the range of 50~175 with increment by 5")


def Ventricular_Amplitude_Error():
    tkinter.messagebox.showerror('Error', 'Invalid Ventricular Amplitude entered!\nPlease use another number!')
    tkinter.messagebox.showinfo('Tips', 'The value should be the one in the list below:\n off\t1.25\t2.5\t3.75\t5.0')


def Atrial_Amplitude_Error():
    tkinter.messagebox.showerror('Error', 'Invalid Atrial Amplitude entered!\nPlease use another number!')
    tkinter.messagebox.showinfo('Tips', 'The value should be the one in the list below:\n off\t1.25\t2.5\t3.75\t5.0')


def Ventricular_Pulse_Width_Error():
    tkinter.messagebox.showerror('Error',
                                 'Invalid Ventricular Pulse Width entered!\nPlease use another number!')
    tkinter.messagebox.showinfo('Tips',
                                'The value should be in one of the list below:\n- 0.05\n- 0.1~1.9 with increment by 0.1')


def Atrial_Pulse_Width_Error():
    tkinter.messagebox.showerror('Error',
                                 'Invalid Atrial Pulse Width entered!\nPlease use another number!')
    tkinter.messagebox.showinfo('Tips',
                                'The value should be in one of the list below:\n- 0.05\n- 0.1~1.9 with increment by 0.1')


def ARP_Error():
    tkinter.messagebox.showerror('Error', 'Invalid ARP entered!\nPlease use another number!')
    tkinter.messagebox.showinfo('Tips', 'The value should be in the range of 150~500 with the increment by 10')


def Atrial_Sensitivity_Error():
    tkinter.messagebox.showerror('Error', 'Invalid Atrial Sensitivity entered!\nPlease use another number!')
    tkinter.messagebox.showinfo('Tips',
                                'The value should be in the list below:\n- 0.25\t0.5\t0.75\n- 1.0~10 with the increment by 0.5')


def Hysteresis_Error():
    tkinter.messagebox.showerror('Error', 'Invalid Hysteresis entered!\nPlease use another number!')
    tkinter.messagebox.showinfo('Tips',
                                'The value should be in the list below:\n- off\n- 30~50 with increment by 5\n -50~90 with increment by 1\n -  90~175 with increment by 5')


def Rate_Smoothing_Error():
    tkinter.messagebox.showerror('Error', 'Invalid Hysteresis entered!\nPlease use another number!')
    tkinter.messagebox.showinfo('Tips',
                                'The value should be in the list below:\n- off\n- 3\t6\t9\t12\n- 15\t18\t21\t25\n(note:the system has % already,you just put an integer here!')

def PVARP_Error():
    tkinter.messagebox.showerror('Error', 'Invalid PVARP entered!\nPlease use another number!')
    tkinter.messagebox.showinfo('Tips',
                                'The value should be in the range of 150~500 with the increment by 10')

# def Amplitude_Error():
#     tkinter.messagebox.showerror('Error', 'Invalid Amplitude entered!\nPlease use another number!')
#     tkinter.messagebox.showinfo('Tips',
#                                 'The value should be in the list below:\n- off\n- 3\t6\t9\t12\n- 15\t18\t21\t25')


# def Pulse_Width_Error():
#     tkinter.messagebox.showerror('Error', 'Invalid Pulse width entered!\nPlease use another number!')



